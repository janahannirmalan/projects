Java Assignment
======

This assignment is a Java implementation of a "day sheet generator."  The appointment data is 
stored in an array as YAML. 

You have all resources available to you (internet, the interviewer, etc)

Please complete the following tasks:

 1. Import the project into your IDE, if any
 2. Read the YAML appointments
 3. Sort the appointments by date
 3. Print the appointments to stdout
